import React, { Component } from 'react';
import Select from 'react-select';
import { Link } from 'react-router-dom';
import axios from 'axios';
import Helmet from 'react-helmet';
import Img1 from '../Images/logo.png';
import { apiURL } from '../Config/Config';

class Programs extends Component {

    state = {
        selectProgramOptions: [],
        programId: [],
        program_name: '',
        loading: true
    };

    componentDidMount() {
        this.getProgramsData()
    }
    token = localStorage.getItem("token");
    
    async getProgramsData() {
        const config = {
            headers: { Authorization: `Bearer ${this.token}` }
        };
        const res = await axios.get(`${apiURL}api/users/program`, config)
        const data = res.data.data;

        const options = data.map(item => ({
            "value": item.id,
            "label": item.program_name
        }))
        this.setState({ selectProgramOptions: options, loading: false })
    }

    async handleChangeProgram(e) {
        let idArr = []
        e.map((i) => {
            if (!idArr.includes(i.value)) {
                idArr.push(i.value)
            }
        })
        await this.setState({ programId: idArr })
    }

    ProgramDataPost = async () => {
        if (this.state.programId.length) {
            const config = {
                headers: { Authorization: `Bearer ${this.token}` }
            };
            const bodyParameters = {
                "program_id": this.state.programId
            };
            await axios.post(`${apiURL}api/users/program`, bodyParameters, config);
        }
        else {
            alert("this field is required !")
        }
    }

    render() {
        const { selectProgramOptions, loading } = this.state;

        const content = loading ? <h1 className='loader' ></h1> : (<div className="container-fluid">
            <div className="row" style={{ backgroundColor: "#00274A", height: "100vh" }}>
                <div className="col-md-offset-3">
                    <form id="msform">
                        <ul id="progressbar" className='d-flex justify-content-center'>
                            <li className="me-5"></li>
                            <li className='me-5'></li>
                            <li className='active me-5'></li>
                            <li className='me-5'></li>
                            <li className='me-5'></li>
                        </ul>

                        <fieldset>
                            <img src={Img1} alt="not-found" style={{ width: "100px" }} />
                            <h2 className="mt-3 mb-4">What Kind of Course Level are you Interested in?</h2>
                            <Select
                                name="program_name"
                                value={this.state.selectedOptions}
                                options={selectProgramOptions}
                                onChange={this.handleChangeProgram.bind(this)}
                                placeholder="Select Course Level"
                                isMulti={true}
                                className="mb-3"
                            />
                            <Link to="/country">
                                <button type="button" name="previous" className="previous action-button-previous">Back</button>
                            </Link>
                            {
                                this.state.programId.length ? <Link to='/domain'>
                                    <button type="submit" name="next" className="next action-button" onClick={this.ProgramDataPost} >Next</button>
                                </Link> : <Link to='/programs'>
                                    <button type="button" name="next" className="next action-button" onClick={this.ProgramDataPost} >Next</button>
                                </Link>
                            }
                        </fieldset>
                    </form>
                </div>
            </div>
        </div>)

        return (
            <>
                <Helmet>
                    <title>The Compass</title>
                </Helmet>
                {
                    content
                }
            </>
        );
    }
}
export default Programs;
