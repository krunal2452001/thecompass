import React from 'react';
import { Routes, Route, BrowserRouter } from 'react-router-dom';

import SignUp from './routes/SignUp';
import Login from './routes/Login';
import Countries from './Countries';
import Programs from './Programs';
import Plan from './routes/Plan';
import Domain from './routes/Domain';
import Home from './routes/Home';
import PageNotFound from './routes/PageNotFound';
import "../node_modules/bootstrap/dist/css/bootstrap.min.css";
import "../node_modules/bootstrap/dist/js/bootstrap.bundle.js";

const App = () => {
  return (
    <>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<SignUp />} />
          <Route path="/login" element={<Login />} />
          <Route path='/country' element={<Countries />} />
          <Route path="/programs" element={<Programs />} />
          <Route path="/domain" element={<Domain />} />
          <Route path='/planning' element={<Plan />} />
          <Route path='/home' element={<Home />} />
          <Route path="*" element={<PageNotFound />} />
        </Routes>
      </BrowserRouter>
    </>
  );
}
export default App;