import React from 'react';
import { Field, Form, Formik } from 'formik';
import { Link, useNavigate } from 'react-router-dom';
import axios from 'axios';
import Helmet from 'react-helmet';

import { TextField } from './TextField';
import Val_Signup from '../../Validation/Val_Signup';
import Img1 from "../../Images/logo.png"
import { apiURL } from '../../Config/Config';

const SignUp = () => {
    const navigate = useNavigate();

    const handleSignUp = async (values) => {

        try {
            const res = await axios.post(`${apiURL}api/users/signup`, values);
            const token = res.data.token;
            const studentId = res.data.data.userId;
            localStorage.setItem("token", token)
            localStorage.setItem("studentId", studentId)

            if (res.data.msg == "User already exist!") {
                alert("User already exist !")
                navigate("/login")
            }
            else {
                alert("SignUp Successfully !")
                navigate("/country")
            }

        } catch (error) {
            console.log(error);
        }
    }
    return (
        <>
            <Helmet>
                <title>Register</title>
            </Helmet>

            <Formik
                initialValues={{
                    first_name: "",
                    last_name: "",
                    gender: "",
                    phone_number: "",
                    city: "",
                    email: "",
                    password: "",
                    confirm_password: "",

                }}
                validationSchema={Val_Signup}
                onSubmit={(values, { resetForm }) => {
                    resetForm({ values: "" });
                    handleSignUp(values);
                }}
            >

                <div className="container-fluid">
                    <div className="row justify-content-center d-flex" style={{ backgroundColor: "#00274A" }}>
                        <Form id="msform" className='container'>
                            <div className="col-md-3 col-12 mx-auto">
                                <ul id="progressbar" className='text ps-0 center d-flex justify-content-between'>
                                    <li className="active "></li>
                                    <li className=''></li>
                                    <li className=''></li>
                                    <li className=''></li>
                                    <li className=''></li>
                                </ul>
                            </div>
                            <div className='col-12'>

                                <fieldset>
                                    <img src={Img1} alt="not-found" style={{ width: "100px" }} />
                                    <h2 className='mt-3 mb-4'>Register Today !</h2>
                                    <p><b>Please Enter your Basic Details</b></p>
                                    <div className="row">

                                        <div className="col-md-6 col-12">
                                            <TextField type="text" name="first_name" placeholder="First Name" className="form-control rounded" />
                                        </div>
                                        <div className="col-md-6 col-12">
                                            <TextField type="text" name="last_name" placeholder="Last Name" className="form-control rounded" />
                                        </div>

                                        <div className="col-md-6 col-12">
                                            <Field as="select" name="gender" className="form-control mt-4" style={{ height: "50px" }}>
                                                <option value="">Select Gender</option>
                                                <option value="male">Male</option>
                                                <option value="female">Female</option>
                                                <option value="other">Other</option>
                                            </Field>
                                        </div>
                                        <div className="col-md-6 col-12">
                                            <Field as="select" name="city" className="form-control mt-4" style={{ height: "50px" }}>
                                                <option value="">Select City</option>
                                                <option value="surat">Surat</option>
                                                <option value="surat">Vadodara</option>
                                                <option value="surat">Anand</option>
                                            </Field>
                                        </div>
                                        <div className="col-md-6 col-12">
                                            <TextField type="tel" name="phone_number" placeholder="Phone Number" className="form-control rounded" />
                                        </div>
                                        <div className="col-md-6 col-12">
                                            <TextField type="email" name="email" placeholder="Email Id" className="form-control rounded" />
                                        </div>
                                        <div className="col-md-6 col-12">
                                            <TextField type="password" name="password" placeholder="Password" className="form-control rounded" />
                                        </div>

                                        <div className="col-md-6 col-12">
                                            <TextField type="password" name="confirm_password" placeholder="Confirm Password" className="form-control rounded" />
                                        </div>
                                    </div>
                                    <br />
                                    <button type="submit" name="submit" className="action-button mt-0">Register</button>
                                    <div className='mt-3'>
                                        <h6>Already a Member ?
                                            <Link to="/login" className='text-decoration-none'>{` `}Login</Link>
                                        </h6>
                                    </div>
                                </fieldset>
                            </div>
                        </Form>
                    </div>
                </div>
            </Formik>
        </>
    )
}
export default SignUp;