import React, { useState, useEffect } from 'react';
import QRCode from 'qrcode';
import jsPDF from 'jspdf';
import axios from 'axios';
import Helmet from 'react-helmet';
import Header from '../../Header';
import logo from "../../Images/logo.png";
import { apiURL } from '../../Config/Config';

const Home = () => {
    const [url, setUrl] = useState(localStorage.getItem("studentId"))
    const [qr, setQr] = useState('')
    const [student, setStudent] = useState([]);
    const [university, setUniversity] = useState([]);
    const [loading, setLoading] = useState(true);
    useEffect(() => {
        getUniversityList();
    }, [])

    const token = localStorage.getItem("token")

    const getUniversityList = async () => {

        await QRCode.toDataURL(url, {
            width: 800,
            margin: 2,
            color: {
                dark: '#000000',
                light: '#ffffff',
            }
        }, (err, url) => {
            if (err) return console.error(err)
            setQr(url)
        })

        const config = {
            headers: { Authorization: `Bearer ${token}` }
        };
        const getData = await axios.get(`${apiURL}api/users/university`, config)
        setUniversity(getData.data.data.universityData)
        setStudent(getData.data.data)
        localStorage.setItem("university", JSON.stringify(getData.data.data.universityData))
        setUrl(localStorage.getItem("studentid"))
        setLoading(false)
    }

    const generatePDF = () => {
        let doc = new jsPDF("p", "pt", "a4");
        doc.html(document.querySelector("#content"), {
            callback: function (pdf) {
                pdf.save("mypdf.pdf");
            },
        })
    }

    const content = loading ? <h1 className='loader' ></h1> : (<><div className="container-fluid  bg-white" >
        
    </div>
        <div className="container-fluid p-0" style={{ marginTop: 100 }}>
            <h2 className='text-center text-white mt-5 pt-2 pb-2' style={{ backgroundColor: "#00274A" }}>University List</h2>
            <div className='table-responsive'>
                <table className="table table-hover" style={{ cursor: "pointer" }}>
                    <thead>
                        <tr>
                            <th>#</th>
                            <th scope="col">Name</th>
                            <th scope="col">Country</th>
                        </tr>
                    </thead>
                    <tbody>
                        {
                            Object.keys(university).map((item, i) => (
                                <tr>
                                    <td>{i + 1}</td>
                                    <td>{university[item].university}</td>
                                    <td>{university[item].country}</td>
                                </tr>
                            ))
                        }
                    </tbody>
                </table>
            </div>
        </div></>)
    return (
        <>
            <Helmet>
                <title>The Compass</title>
            </Helmet>

            <Header />
            {
                content
            }
        </>
    )
}
export default Home;