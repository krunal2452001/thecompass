import React from 'react'
import { Formik, Form } from 'formik';
import { Link, useNavigate } from 'react-router-dom';
import axios from 'axios';
import Helmet from 'react-helmet';
import { toast, ToastContainer } from 'react-toastify';

import { TextField } from './TextField';
import Val_Signin from '../../Validation/Val_Signin';
import Img1 from "../../Images/logo.png"
import { apiURL } from '../../Config/Config';
import 'react-toastify/dist/ReactToastify.css';

const Login = () => {
    const navigate = useNavigate();
    const handleSignin = async (values) => {
        try {
            const res = await axios.post(`${apiURL}api/users/login`, values)
            const message = res.data.msg;
            const token = res.data.token;
            const userData = res.data.data;
            const studentId = res.data.data.id;
            localStorage.setItem("userData", JSON.stringify(userData))
            localStorage.setItem("token", token)
            localStorage.setItem("studentId", studentId)

            if (token) {
                if (message == "Logged in successfully!") {
                    toast.success("You Redirected to Home Page !")
                    setTimeout(() => {
                        navigate("/home")
                    }, 1000)
                }
            }
            else {
                toast.warning("Credential not found , Please Signup First !")
                setTimeout(() => {
                    navigate("/")
                }, 1000)
            }
        } catch (error) {
            console.log(error)
        }
    }
    return (
        <>
            <Helmet>
                <title>Login</title>
            </Helmet>
            <Formik
                initialValues={{
                    email: "",
                    password: "",
                }}
                validationSchema={Val_Signin}
                onSubmit={(values, { resetForm }) => {
                    resetForm({ values: "" });
                    handleSignin(values);
                }}
            >
                <div className="container-fluid">
                    <div className="row pt-5" style={{ backgroundColor: "#00274A", height: "100vh" }}>
                        <div className="col-md-offset-3">
                            <Form id="msform">
                                <fieldset>
                                <img src={Img1} alt="not-found" style={{width : "100px"}} />
                                    <h2 className="mt-3 mb-4">Login</h2>
                                    <p><b>Please Enter your Email id and Password</b></p>

                                    <div className="row">
                                        <div className="col-md-6 col-12">
                                            <TextField
                                                name="email"
                                                type="email"
                                                placeholder="Enter Your Email"
                                            />
                                        </div>
                                        <div className="col-md-6 col-12">
                                            <TextField
                                                name="password"
                                                type="password"
                                                placeholder="Enter Your Password"
                                            />
                                        </div>
                                    </div>
                                    <br />
                                    <button type="submit" className="action-button mt-0">Login</button>
                                    <div className='mt-3'>
                                        <h6>New Member ?
                                            <Link to="/" className='text-decoration-none' >{` `}SignUp</Link>
                                        </h6>
                                    </div>
                                </fieldset>
                                <ToastContainer />
                            </Form>
                        </div>
                    </div>
                </div>
            </Formik>
        </>
    )
}
export default Login;