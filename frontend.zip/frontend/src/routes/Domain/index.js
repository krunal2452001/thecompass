import React, { Component } from 'react';
import Select from 'react-select';
import { Link } from 'react-router-dom';
import axios from 'axios';
import Helmet from 'react-helmet';
import Img1 from '../../Images/logo.png';
import { apiURL } from '../../Config/Config';

class Domain extends Component {

    state = {
        selectDomainOptions: [],
        domainId: [],
        domain: '',
        loading: true
    };

    componentDidMount() {
        this.getDomainData()
    }
    token = localStorage.getItem("token");

    async getDomainData() {
        const config = {
            headers: { Authorization: `Bearer ${this.token}` }
        };
        const res = await axios.get(`${apiURL}api/users/domain`, config)
        const data = res.data.data;
        const options = data.map(item => ({
            "value": item.id,
            "label": item.domain
        }))
        this.setState({ selectDomainOptions: options, loading: false })
    }

    async handleChangeDomain(e) {
        let idArr = []
        e.map((i) => {
            if (!idArr.includes(i.value)) {
                idArr.push(i.value)
            }
        })
        await this.setState({ domainId: idArr })
    }

    DomainDataPost = async () => {
        if (this.state.domainId.length) {
            const config = {
                headers: { Authorization: `Bearer ${this.token}` }
            };
            const bodyParameters = {
                "domain_id": this.state.domainId
            };
            await axios.post(`${apiURL}api/users/domain`, bodyParameters, config);
        }
        else {
            alert("this field is required !")
        }
    }

    render() {
        const { selectDomainOptions, loading } = this.state;

        const content = loading ? <h1 className='loader' ></h1> : (<div className="container-fluid">
            <div className="row" style={{ backgroundColor: "#00274A", height: "100vh" }}>
                <div className="col-md-offset-3">
                    <form id="msform">
                        <ul id="progressbar" className='d-flex justify-content-center'>
                            <li className="me-5"></li>
                            <li className='me-5'></li>
                            <li className='me-5'></li>
                            <li className='active me-5'></li>
                            <li className='me-5'></li>
                        </ul>
                        <fieldset>
                            <img src={Img1} alt="not-found" style={{ width: "100px" }} />
                            <h2 className="mt-3 mb-4">Which Field of study are you Looking for ?</h2>
                            <Select
                                name="domain"
                                value={this.state.selectOptions}
                                options={selectDomainOptions}
                                onChange={this.handleChangeDomain.bind(this)}
                                placeholder="Select Fields"
                                isMulti={true}
                                className="mb-3"
                            />
                            <Link to="/programs">
                                <button type="button" name="previous" className="previous action-button-previous">Back</button>
                            </Link>
                            {
                                this.state.domainId.length ? <Link to='/planning'>
                                    <button type="submit" name="next" className="next action-button" onClick={this.DomainDataPost}>Next</button>
                                </Link> : <Link to='/domain'>
                                    <button type="button" name="next" className="next action-button" onClick={this.DomainDataPost}>Next</button>
                                </Link>
                            }
                        </fieldset>
                    </form>
                </div>
            </div>
        </div>)

        return (
            <>
                <Helmet>
                    <title>Fields</title>
                </Helmet>
                {
                    content
                }
            </>
        );
    }
}
export default Domain;