import React from 'react'
import { Link } from 'react-router-dom';

const ForgotPassword = () => {
    return (
        <>
            <div className="container-fluid">
                <div className="row pt-5" style={{ backgroundColor: "#00274A", height: "100vh" }} >
                    <div className="col-md-offset-3">
                        <form id="msform">
                            <fieldset>
                                <h3 className="mt-3 mb-4">Forgot Password</h3>
                                <p><b>Please enter your E-mail we will send you a link to reset your password</b></p>
                                <div className="row">
                                    <div className="col-md-12 col-12">
                                        <input type="email" name="email" placeholder="Enter Your Email" className='form-control rounded' />
                                    </div>
                                </div>
                                <button type="submit" className="next action-button" onClick={(e) => e.preventDefault(e)}>Submit</button>
                            </fieldset>
                        </form>
                    </div>
                </div>
            </div>
        </>
    )
}
export default ForgotPassword;