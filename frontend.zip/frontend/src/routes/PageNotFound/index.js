import React from 'react';

const PageNotFound = () => {
    return (
        <>
            <div className="container">
                <div className="row text-center mt-5">
                    <h1><b>Page Not Found</b></h1>
                    <h5 style={{color: "#6d6d6d"}} className="mt-3">We couldn't find what you were looking for.</h5>
                    <h6 className="mt-3">Please contact the owner of the site that linked you to the original URL and let them know their link is broken.</h6>
                </div>
            </div>
        </>
    )
}
export default PageNotFound;