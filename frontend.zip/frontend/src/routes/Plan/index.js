import React, { Component } from 'react';
import Select from 'react-select';
import { Link } from 'react-router-dom';
import axios from 'axios';
import Helmet from 'react-helmet';

import Img1 from '../../Images/logo.png';
import { apiURL } from '../../Config/Config';

class Plan extends Component {

    state = {
        selectOptions: [],
        value: '',
        joining_year: ''
    };

    componentDidMount() {
        this.getPlaningData()
    }

    async getPlaningData() {
        const options = [
            { value: '2023', label: '2023' },
            { value: '2024', label: '2024' },
            { value: '2025', label: '2025' },
            { value: '2026', label: '2026' },
            { value: '2027', label: '2027' },
            { value: '2028', label: '2028' },
            { value: '2029', label: '2029' },
            { value: '2030', label: '2030' },
        ];
        this.setState({ selectOptions: options })
    }

    idArr = [];
    async handleChange(e) {
        let idArr = []
        await this.setState({ value: idArr, joining_year: e.label })

    }
    token = localStorage.getItem("token");

    PlaningDataPost = async () => {
        if (this.state.joining_year) {
            const config = {
                headers: { Authorization: `Bearer ${this.token}` }
            };
            const bodyParameters = {
                "year": this.state.joining_year
            };
            await axios.post(`${apiURL}api/users/year`, bodyParameters, config);
        } else {
            alert("this field is required ")
        }
    }

    render() {
        const { selectedOption } = this.state;

        return (
            <>
                <Helmet>
                    <title>RG || Planing Year</title>
                </Helmet>
                <div className="container-fluid">
                    <div className="row" style={{ backgroundColor: "#00274A", height: "100vh" }}>
                        <div className="col-md-offset-3">
                            <form id="msform">
                                <ul id="progressbar" className='d-flex justify-content-center'>
                                    <li className=" me-5"></li>
                                    <li className='me-5'></li>
                                    <li className='me-5'></li>
                                    <li className=' me-5'></li>
                                    <li className='active me-5'></li>
                                </ul>

                                <fieldset>
                                    <img src={Img1} alt="not-found" style={{ width: "100px" }} />
                                    <h2 className="mt-3 mb-4">When are you planning to go?</h2>
                                    <Select
                                        name="joining_year"
                                        value={selectedOption}
                                        options={this.state.selectOptions}
                                        onChange={this.handleChange.bind(this)}
                                        placeholder="Select Joining Year"
                                        className="mb-3"
                                    />
                                    <Link to="/domain">
                                        <button type="button" name="previous" className="previous action-button-previous">Back</button>
                                    </Link>
                                    {
                                        this.state.joining_year ? <Link to='/home'>
                                            <button type="submit" name="next" className="next action-button" onClick={this.PlaningDataPost} >Next</button>
                                        </Link> : <Link to='/planning'>
                                            <button type="button" name="next" className="next action-button" onClick={this.PlaningDataPost} >Next</button>
                                        </Link>
                                    }
                                </fieldset>
                            </form>
                        </div>
                    </div>
                </div>
            </>
        );
    }
}
export default Plan;