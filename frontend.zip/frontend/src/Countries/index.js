import React, { Component } from 'react';
import Select from 'react-select';
import { Link } from 'react-router-dom';
import axios from 'axios';
import Helmet from 'react-helmet';
import Header from '../Header';
import { apiURL } from '../Config/Config';
import Img1 from '../Images/logo.png';

class Countries extends Component {

    state = {
        selectCountryOptions: [],
        id: [],
        name: '',
        loading: true
    };

    componentDidMount() {
        this.getCountryData()
    }

    async getCountryData() {
        const res = await axios.get(`${apiURL}api/users/country`)
        const data = res.data.data;

        const options = data.map(item => ({
            "value": item.id,
            "label": item.name
        }))
        this.setState({ selectCountryOptions: options, loading: false })
    }

    idArr = [];
    async handleChange(e) {
        let idArr = []
        e.map((i) => {
            if (!idArr.includes(i.value)) {
                idArr.push(i.value)
            }
        })
        await this.setState({ id: idArr, name: e.label })
    }
    token = localStorage.getItem("token");

    CountryDataPost = async () => {
        if (this.state.id.length) {
            const config = {
                headers: { Authorization: `Bearer ${this.token}` }
            };
            const bodyParameters = {
                "country_id": this.state.id
            };
            await axios.post(`${apiURL}api/users/country`, bodyParameters, config)
        }
        else {
            alert("this field is required !")
        }
    }
    render() {
        const { selectCountryOptions, loading } = this.state;

        const content = loading ? <h1 className='loader' ></h1> : (<div className="container-fluid">
            <div className="row" style={{ backgroundColor: "#00274A", height: "100vh" }}>
                <div className="col-md-offset-3">
                    <form id="msform">
                        <ul id="progressbar" className='d-flex justify-content-center'>
                            <li className="me-5"></li>
                            <li className='active me-5'></li>
                            <li className='me-5'></li>
                            <li className='me-5'></li>
                            <li className='me-5'></li>
                        </ul>

                        <fieldset>
                            <img src={Img1} alt="not-found" style={{ width: "100px" }} />
                            <h2 className="mt-3 mb-4">Which Countries are you Targeting?</h2>
                            <Select
                                name="name"
                                value={this.state.selectedOption}
                                options={selectCountryOptions}
                                onChange={this.handleChange.bind(this)}
                                placeholder="Select Country"
                                isMulti={true}
                                className="mb-3"

                            />{this.state.id.length ?
                                <Link to='/programs'>
                                    <button type="submit" name="next" className="next action-button" onClick={this.CountryDataPost}>Next</button>
                                </Link> : <Link to='/country'>
                                    <button type="button" name="next" className="next action-button" onClick={this.CountryDataPost}>Next</button>
                                </Link>}
                        </fieldset>
                    </form>
                </div>
            </div>
        </div>)
        return (
            <>
                <Helmet>
                    <title>RG || Countries</title>
                </Helmet>
                {
                    content
                }
            </>
        );
    }
}
export default Countries;