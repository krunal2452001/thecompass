module.exports = {
    apiURL: "http://localhost:3001/",
    // apiURL: "http://13.233.42.166:3001/"
}