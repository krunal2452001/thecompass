import * as Yup from "yup";
const phoneRegExp = /^((\\+[6-9]{1,4}[ \\-]*)|(\\([0-9]{2,3}\\)[ \\-]*)|([0-9]{2,4})[ \\-]*)*?[0-9]{3,4}?[ \\-]*[0-9]{3,4}?$/
const emailRegExp = /^[^\s@]+@[^\s@]+\.[^\s@]{2,3}$/i;

const Val_Signup = Yup.object({
    first_name: Yup.string()
        .required("First Name is required"),
    last_name: Yup.string()
        .required("Last Name is required"),
    gender: Yup.string()
        .required("Gender is required"),
    phone_number: Yup.string()
        .required("Phone Number is required")
        .matches(phoneRegExp, 'Phone number is not valid')
        .min(10, "to short")
        .max(10, "to long"),
    city: Yup.string()
        .required("City is required"),
    email: Yup.string()
        .required("Email Address is required")
        .matches(emailRegExp, 'Email Address is not valid'),
    password: Yup.string()
        .required("Password is required")
        .min(4, "Password is too short - should be 8 chars minimum."),
    // .matches(
    //     /^.*((?=.*[!@#$%^&*()\-_=+{};:,<.>]){1})(?=.*\d)((?=.*[a-z]){1})((?=.*[A-Z]){1}).*$/,
    //     "Your password must contain a Letter, a Capital Letter, a Number and a Symbol."
    // ),
    confirm_password: Yup.string()
        .oneOf([Yup.ref("password"), ""], "Password must match")
        .required("Confirm Password is required"),
});

export default Val_Signup;
