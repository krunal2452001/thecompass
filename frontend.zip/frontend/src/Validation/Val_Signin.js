import * as Yup from "yup";
const emailRegExp = /^[^\s@]+@[^\s@]+\.[^\s@]{2,3}$/i;

const Val_Signin = Yup.object({
    email: Yup.string()
        .required("Email Address is required")
        .matches(emailRegExp, 'Email Address is not valid'),
    password: Yup.string()
        .required("Password is required")
        .min(8, "Password is too short - should be 8 chars minimum.")
        // .matches(
        //     /^.*((?=.*[!@#$%^&*()\-_=+{};:,<.>]){1})(?=.*\d)((?=.*[a-z]){1})((?=.*[A-Z]){1}).*$/,
        //     "Your password must contain a Letter, a Capital Letter, a Number and a Symbol."
        // ),
});
export default Val_Signin;
